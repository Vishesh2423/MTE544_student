
from mapUtilities import *
from a_star import *

POINT_PLANNER=0; TRAJECTORY_PLANNER=1
import os
HERE = os.path.dirname(os.path.abspath(__file__))

class planner:
    def __init__(self, type_, mapName="room", heuristic=EUCLIDEAN):

        self.type=type_
        self.mapName=mapName
        self.heuristic=heuristic    # A* heuristic: EUCLIDEAN or MANHATTAN (from a_star.py)

    
    def plan(self, startPose, endPose):
        
        if self.type==POINT_PLANNER:
            return self.point_planner(endPose)
        
        elif self.type==TRAJECTORY_PLANNER:
            self.costMap=None
            self.initTrajectoryPlanner()
            return self.trajectory_planner(startPose, endPose)


    def point_planner(self, endPose):
        return endPose

    def initTrajectoryPlanner(self):


        # TODO PART 5 Create the cost-map, the laser_sig is 
        # the standard deviation for the gausiian for which
        # the mean is located on the occupant grid. 
        self.m_utilites = mapManipulator(os.path.join(HERE, "edited_second", "edited_second.yaml"), laser_sig=0.5)
            
        self.costMap=self.m_utilites.make_likelihood_field()
        

    def trajectory_planner(self, startPoseCart, endPoseCart):


        # This is to convert the cartesian coordinates into the 
        # the pixel coordinates of the map image, remmember,
        # the cost-map is in pixels. You can by the way, convert the pixels
        # to the cartesian coordinates and work by that index, the a_star finds
        # the path regardless. 
        startPose=self.m_utilites.position_2_cell(startPoseCart)
        endPose=self.m_utilites.position_2_cell(endPoseCart)
        
        # TODO PART 5 convert the cell pixels into the cartesian coordinates
        # Run A* on the cost map with the chosen heuristic
        path_cells = search(self.costMap, startPose, endPose, self.heuristic)
        if path_cells is None:
            print("No path found bruh...")
            return None

        Path = list(map(self.m_utilites.cell_2_position, path_cells))

        # TODO PART 5 return the path as list of [x,y]
        return Path




if __name__=="__main__":

    m_utilites=mapManipulator()
    
    map_likelihood=m_utilites.make_likelihood_field()

    # you can use this part of the code to test your 
    # search algorithm regardless of the ros2 hassles
    
